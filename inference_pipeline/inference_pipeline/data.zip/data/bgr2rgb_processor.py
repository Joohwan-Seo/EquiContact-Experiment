import cv2
import numpy as np

# read the image
def bgr2rgb_processor(image_path):
    # Read the image using OpenCV
    image = cv2.imread(image_path)

    # Check if the image was loaded successfully
    if image is None:
        raise ValueError(f"Image at path {image_path} could not be loaded.")

    # Convert BGR to RGB
    rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

    return rgb_image

if __name__ == "__main__":
    # Example usage
    dir = "tilted_image_handeye"
    image_path = f"{dir}/realsense.png"
    rgb_image = bgr2rgb_processor(image_path)
    
    # Display the converted image (optional)
    cv2.imshow("RGB Image", rgb_image)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

    # Save the RGB image if needed
    cv2.imwrite(f"{dir}/realsense_corrected.png", rgb_image)