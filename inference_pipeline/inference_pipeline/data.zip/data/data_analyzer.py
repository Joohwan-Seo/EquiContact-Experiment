import pickle
import numpy as np
from matplotlib import pyplot as plt

def load_data(file_path):
    """
    Load data from a pickle file.
    
    :param file_path: Path to the pickle file.
    :return: Loaded data.
    """
    with open(file_path, 'rb') as file:
        data = pickle.load(file)
    return data

def main():
    compact_dir = "data/CompACT"
    compact_data = []
    default_data = []
    for i in range(5):
        file_path = f"{compact_dir}_{i}.pkl"

        data_list = load_data(file_path)
        compact_data.append(np.array(data_list))
    
        default_list = load_data(f"data/world_pose_gac_{i}.pkl")
        default_data.append(np.array(default_list))

    compact_data = np.abs(np.array(compact_data))
    default_data = np.abs(np.array(default_data))
    print("Compact Data Shape:", compact_data.shape)
    print("Default Data Shape:", default_data.shape)

    mean_compact = np.mean(compact_data, axis=0)
    mean_default = np.mean(default_data, axis=0)

    std_compact = np.std(compact_data, axis=0)
    std_default = np.std(default_data, axis=0)

    # Make a figure with subplots for each dimension
    # print using mean and the std
    # solid line for the mean value and shaded area for the std deviation

    plt.figure(figsize=(12, 8))
    for i in range(mean_compact.shape[1]):
        plt.subplot(2, 3, i + 1)
        plt.plot(mean_compact[:, i], label='Compact Mean', color='blue')
        plt.fill_between(range(mean_compact.shape[0]), 
                         mean_compact[:, i] - std_compact[:, i], 
                         mean_compact[:, i] + std_compact[:, i], 
                         color='blue', alpha=0.2)

        plt.plot(mean_default[:, i], label='Default Mean', color='orange')
        plt.fill_between(range(mean_default.shape[0]), 
                         mean_default[:, i] - std_default[:, i], 
                         mean_default[:, i] + std_default[:, i], 
                         color='orange', alpha=0.2)

        plt.title(f'Dimension {i+1}')
        plt.xlabel('Time Step')
        plt.ylabel('Value')
        plt.legend()
        
    plt.tight_layout()
    plt.show()

   

if __name__ == "__main__":
    main()